package Constant;

import org.openqa.selenium.WebDriver;

public class Constant {
	public static WebDriver WEBDRIVER;
	public static final String RAIWAY_URL = "http://192.168.172.24:8083/Page/HomePage.cshtml";
	public static final String USERNAME = "seltrain2015@gmail.com";
	public static final String PASSWORD = "12345678";
	public static final String GMAIL= "https://www.google.com/gmail/";
	
	public static final String USERNAME_GMAIL = "seltrain2015@gmail.com";
	public static final String PASSWORD_GMAIL = "!logigear123";
	

}
