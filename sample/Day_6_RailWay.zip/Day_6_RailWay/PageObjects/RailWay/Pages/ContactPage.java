package RailWay.Pages;


public class ContactPage extends GeneralPageRailway{

}
